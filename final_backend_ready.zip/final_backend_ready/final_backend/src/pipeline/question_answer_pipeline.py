import os
import requests
from src.components.rag_pipeline import RAGPipeline
from langchain_community.vectorstores import FAISS
from src.utils.synonym_expander import SynonymExpander


class QuestionAnswerPipeline:
    def __init__(self):
        self.rag = RAGPipeline()

    def sanitize_text(self, text: str) -> str:
        return text.encode("utf-8", "replace").decode("utf-8")

    def run(self, question, chat_id, document_id=None, combine_docs=None, return_sources: bool = False):
        try:
            if not question:
                return "❌ No question provided."

            if isinstance(question, list):
                question = " ".join(str(q) for q in question)
            elif not isinstance(question, str):
                raise Exception("❌ Invalid input: 'question' must be a string.")

            question = question.strip()
            if not question:
                return "❌ Question is empty after stripping."

            expander = SynonymExpander()
            expanded_question = expander.find_similar_words(question)

            keywords = question.lower()
            is_summary_all = (
                (document_id and str(document_id).lower() == "all")
                or not document_id
                or any(kw in keywords for kw in ["summarize", "compare", "difference", "overview", "highlights"])
            )
            is_cost_question = any(kw in keywords for kw in ["cost", "price", "charges", "amount", "budget"])

            # ✅ Combine mode: use specific list of PDFs from this chat
            if combine_docs:
                print("🔗 Combine Mode: Using selected documents only...")
                context, context_map, question_type = self.rag.get_context_from_multiple_docs(
                    question=expanded_question,
                    chat_id=chat_id,
                    document_names=combine_docs,
                    return_doc_map=True
                )

                if not context.strip():
                    return "❗ No relevant content found in the selected documents."

                doc_blocks = []
                for doc, sections in context_map.items():
                    numbered_sections = [f"{i+1}. {self.sanitize_text(s)}" for i, s in enumerate(sections)]
                    doc_blocks.append(f"📄 {doc}:\n" + "\n".join(numbered_sections))
                combined_contexts = "\n\n".join(doc_blocks)

                if is_cost_question or question_type == "cost":
                    prompt = self.build_multi_doc_prompt(question, combined_contexts)
                else:
                    prompt = self.build_summary_prompt(question, combined_contexts)

                print(f"📄 Context from {len(context_map)} selected documents being sent to model.")
                answer = self.call_ollama(prompt)
                return (answer, []) if return_sources else answer

            # 📄 Single-document mode
            if document_id:
                filename = os.path.splitext(os.path.basename(str(document_id)))[0]
                pdf_path = os.path.join("uploaded_docs", chat_id, f"{filename}.pdf")
                vectorstore_folder = os.path.join("vectorstores", chat_id, filename)
                index_file = os.path.join(vectorstore_folder, "index.faiss")

                if not os.path.exists(pdf_path):
                    raise FileNotFoundError(f"📁 Document not found at {pdf_path}")

                if not os.path.exists(index_file):
                    print("⚙️ Vectorstore missing. Attempting regeneration...")
                    self.rag.create_vectorstore(pdf_path)

                context = self.rag.get_context(expanded_question, vectorstore_folder)
                if not context or not context.strip():
                    return "❗ No relevant content found in the document."

                sanitized_context = self.sanitize_text(context)
                prompt = self.build_single_doc_prompt(question, sanitized_context)
                print(f"📄 Sending prompt to model from single document: {filename}")
                answer = self.call_ollama(prompt)

                if return_sources:
                    vectorstore = FAISS.load_local(
                        vectorstore_folder,
                        self.rag.embedding_model,
                        allow_dangerous_deserialization=True
                    )
                    docs = vectorstore.similarity_search(expanded_question, k=5)
                    return answer, docs

                return answer

            return "❌ No document selected."

        except Exception as e:
            print(f"❌ Pipeline Error: {str(e)}")
            return f"❌ Backend Error: {str(e)}" if not return_sources else (f"❌ Backend Error: {str(e)}", [])

    def build_single_doc_prompt(self, question, context):
        return f"""
You are a highly knowledgeable assistant. Your task is to generate a detailed, complete, and precise answer using ONLY the information given below.

Document Content:
-----------------
{context}

User Question:
--------------
{question}

Instructions:
-------------
- Do NOT include filenames or metadata.
- Focus strictly on the content for your answer.
- Use detailed bullet points, breakdowns, and examples if necessary.
- Provide a professional and structured response.
"""

    def build_multi_doc_prompt(self, question, combined_contexts):
        return f"""
You are a finance assistant helping extract and summarize cost-related data from multiple business documents.

Content from all documents:
---------------------------
{combined_contexts}

User Question:
--------------
{question}

Instructions:
-------------
- Carefully extract all **cost values** (e.g., "$20,000", "Rs. 50,000", "₹1L").
- Add up or compare cost values from all documents.
- Provide a **total estimated cost range**.
- Mention which document contained which cost.
- If a document doesn’t include specific costs, say so clearly.
- Respond in a clear, professional format.
"""

    def build_summary_prompt(self, question, combined_contexts):
        return f"""
You are an intelligent assistant. Your task is to summarize the content of the documents below in a clear and structured way.

Content:
--------
{combined_contexts}

User Question:
--------------
{question}

Instructions:
-------------
- Give a concise and structured summary.
- Highlight major sections, themes, or topics.
- Mention any diagrams, tables, or examples if present.
- Do NOT fabricate or include unrelated content.
"""

    def call_ollama(self, prompt):
        url = "http://192.168.0.88:11434/api/generate"
        try:
            safe_prompt = self.sanitize_text(prompt)

            payload = {
                "model": "mistral:instruct",
                "system": "You are a helpful AI assistant. Only use the provided content.",
                "prompt": safe_prompt,
                "stream": False,
                "options": {
                    "temperature": 0.2,
                    "num_predict": 1000
                }
            }

            print("📡 Sending prompt to Ollama...")
            response = requests.post(url, json=payload)
            response.raise_for_status()

            result = response.json().get("response", "").strip()
            if not result:
                raise Exception("Received empty response from Ollama.")

            return result

        except requests.exceptions.ConnectionError:
            return "❌ Ollama server is not reachable. Is it running?"
        except Exception as e:
            print(f"❌ Ollama Error: {str(e)}")
            return f"❌ LLM Error: {str(e)}"