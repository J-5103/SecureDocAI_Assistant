from fastapi import FastAPI, UploadFile, File, HTTPException, Form, Body
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from src.components.plot_generator import PlotGenerator
from src.components.file_loader import FileLoader
from src.pipeline.question_answer_pipeline import QuestionAnswerPipeline
from src.pipeline.document_pipeline import DocumentPipeline
import shutil
import os
from typing import List, Optional

# 🧑‍🎓 Initialize Pipelines
qa_pipeline = QuestionAnswerPipeline()
doc_pipeline = DocumentPipeline()

# 🚀 FastAPI App
app = FastAPI(
    title="SecureDocAI Backend",
    description="Multi-Document AI Chatbot with Vectorstore and Auto Plotting",
    version="1.0.0"
)

# 🌐 Enable CORS for Frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://192.168.0.109:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 📁 Directories
UPLOAD_BASE = "uploaded_docs"
UPLOAD_DIR = "uploaded_excels"
os.makedirs(UPLOAD_BASE, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

# ✅ Upload Single PDF Scoped to Chat
@app.post("/api/upload/upload_file")
async def upload_file(chat_id: str = Form(...), file: UploadFile = File(...)):
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are allowed.")

    try:
        document_id = file.filename  # Use original filename directly
        chat_folder = os.path.join(UPLOAD_BASE, chat_id)
        os.makedirs(chat_folder, exist_ok=True)

        saved_path = os.path.join(chat_folder, document_id)
        with open(saved_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        print(f"✅ Saved: {saved_path}")
        doc_pipeline.run(saved_path, document_id, chat_id=chat_id)

        return {
            "document_path": saved_path,
            "filename": document_id,
            "chat_id": chat_id,
            "status": "vectorstore_created"
        }

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

# ✅ List Documents by Chat ID
@app.get("/list_documents")
async def list_documents(chat_id: str):
    try:
        folder = os.path.join(UPLOAD_BASE, chat_id)
        if not os.path.exists(folder):
            return {"documents": []}
        files = [f for f in os.listdir(folder) if f.endswith(".pdf")]
        return {
            "documents": [
                {"name": f, "documentId": f} for f in files
            ]
        }
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

# ✅ Ask Question for a Chat
class AskRequest(BaseModel):
    chat_id: str
    question: str
    document_id: Optional[str] = None  # 🆕 Support single-doc or combine mode
    combine_docs: Optional[List[str]] = None  # 🔗 Support multiple docs for combine

@app.post("/api/ask")
async def ask_question(request: AskRequest = Body(...)):
    try:
        question = request.question.strip()
        if not question or not request.chat_id:
            raise HTTPException(status_code=400, detail="Missing chat_id or question.")

        # Normalize document_id and combine_docs
        doc_id = None if request.document_id == "combine" else request.document_id
        combine_list = request.combine_docs or None  # Get combine_docs if present

        if combine_list:  # If there are documents in combine mode, join their names into a string
            doc_id = ", ".join(combine_list)  # Concatenate document names for combining

        print(f"🧠 Question: {question} for chat {request.chat_id}\n✉️ Doc: {doc_id}\n🔗 Combine: {combine_list}")

        answer = qa_pipeline.run(
            question=question,
            chat_id=request.chat_id,
            document_id=doc_id,
            combine_docs=combine_list  # Send combine_docs if present
        )

        return {
            "answer": answer,
            "question": question,
            "chat_id": request.chat_id,
            "document_id": request.document_id,
            "combine_docs": request.combine_docs
        }

    except FileNotFoundError:
        return JSONResponse(status_code=404, content={"error": "Document not found."})
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

# ✅ Excel Upload
@app.post("/excel/upload/") 
def upload_excel(file: UploadFile = File(...)):
    try:
        ext = os.path.splitext(file.filename)[-1].lower()
        if ext not in [".xlsx", ".xls", ".csv"]:
            raise HTTPException(status_code=400, detail="Only Excel or CSV files allowed.")

        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        return {"file_path": file_path, "message": "Upload successful."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ✅ Excel Ask Question
@app.post("/excel/ask/") 
def ask_excel_question(file_path: str = Form(...), question: str = Form(...)):
    try:
        df = FileLoader.load_excel_data(file_path)
        question = question.lower()

        numeric_cols = df.select_dtypes(include='number').columns
        if not numeric_cols.any():
            raise HTTPException(status_code=400, detail="No numeric columns found.")

        if "total" in question or "sum" in question:
            answer = df[numeric_cols].sum().to_string()
        elif "average" in question or "mean" in question:
            answer = df[numeric_cols].mean().to_string()
        else:
            raise HTTPException(status_code=400, detail="Unrecognized question.")

        return {"answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ✅ Excel Plot
@app.post("/excel/plot/") 
def plot_excel_data(file_path: str = Form(...), question: str = Form(...)):
    try:
        df = FileLoader.load_excel_data(file_path)
        plot_gen = PlotGenerator(df)
        base64_img = plot_gen.generate_plot(question)
        return {"image_base64": base64_img, "message": "Plot generated successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ✅ Root Health Check
@app.get("/")
async def root():
    return {"message": "✅ SecureDocAI Backend is running"}
