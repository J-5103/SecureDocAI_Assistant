import os
import pdfplumber
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.documents import Document
from src.utils.synonym_expander import SynonymExpander


class RAGPipeline:
    def __init__(self, vector_store_path="vectorstores", ollama_url="http://192.168.0.88:11434/api/generate", model_name="llama3:8b"):
        self.embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        self.vector_store_path = vector_store_path
        self.ollama_url = ollama_url
        self.model_name = model_name

    def sanitize_text(self, text: str) -> str:
        return text.encode("utf-8", "replace").decode("utf-8")

    def detect_question_type(self, question: str) -> str:
        q = question.lower()
        if any(k in q for k in ["cost", "price", "budget", "amount", "charges"]):
            return "cost"
        elif any(k in q for k in ["summary", "tell me about", "describe", "overview"]):
            return "summary"
        return "default"

    def extract_pdf_with_tables(self, pdf_path):
        documents = []
        filename = os.path.basename(pdf_path).replace(".pdf", "")
        try:
            with pdfplumber.open(pdf_path) as pdf:
                for i, page in enumerate(pdf.pages):
                    text = page.extract_text() or ""
                    tables = page.extract_tables()
                    for table in tables:
                        table_text = "\n".join(
                            [" | ".join(cell.strip() if cell else "" for cell in row) for row in table if any(row)]
                        )
                        if table_text.strip():
                            text += f"\n[Extracted Table - Page {i + 1}]\n{table_text}"
                    if text.strip():
                        safe_text = self.sanitize_text(text)
                        documents.append(Document(page_content=safe_text, metadata={"source": filename, "page": i + 1}))
        except Exception as e:
            print(f"❌ Error reading PDF: {e}")
            raise
        return documents

    def create_vectorstore(self, pdf_path=None, combined_text=None, vector_store_path=None, metadata=None):
        try:
            if not combined_text and not pdf_path:
                raise ValueError("Either 'pdf_path' or 'combined_text' must be provided.")

            filename = os.path.basename(pdf_path or "manual_input").replace(".pdf", "")
            vectorstore_folder = vector_store_path or os.path.join(self.vector_store_path, filename)
            os.makedirs(vectorstore_folder, exist_ok=True)

            if combined_text:
                from langchain.schema import Document
                safe_text = self.sanitize_text(combined_text)
                docs = [Document(page_content=safe_text, metadata={"source": filename})]
            else:
                docs = self.extract_pdf_with_tables(pdf_path)

            splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
            chunks = splitter.split_documents(docs)

            vectorstore = FAISS.from_documents(chunks, self.embedding_model)
            vectorstore.save_local(vectorstore_folder)

            print(f"✅ Vectorstore created at: {vectorstore_folder}")

        except Exception as e:
            print(f"❌ create_vectorstore failed: {e}")
            raise

    def get_context(self, question, vectorstore_folder):
        index_file = os.path.join(vectorstore_folder, "index.faiss")
        if not os.path.exists(index_file):
            raise Exception(f"Vectorstore not found at {vectorstore_folder}")

        vectorstore = FAISS.load_local(
            vectorstore_folder,
            self.embedding_model,
            allow_dangerous_deserialization=True
        )

        expander = SynonymExpander()
        expanded_query = expander.find_similar_words(question)

        docs_with_scores = vectorstore.similarity_search_with_score(expanded_query, k=20)
        docs = [doc for doc, score in docs_with_scores if score < 1.0]

        if not docs and docs_with_scores:
            docs = [doc for doc, score in docs_with_scores]

        context = "\n\n".join([self.sanitize_text(doc.page_content) for doc in docs])
        return context

    def create_vectorstore_from_documents(self, documents, vector_store_path: str):
        try:
            safe_docs = [
                Document(page_content=self.sanitize_text(doc.page_content), metadata=doc.metadata)
                for doc in documents
            ]
            vectorstore = FAISS.from_documents(safe_docs, self.embedding_model)
            vectorstore.save_local(vector_store_path)
        except Exception as e:
            raise Exception(f"Failed to create vectorstore: {str(e)}")

    def get_context_from_multiple_docs(self, question, chat_id, document_names=None, top_k=20, return_doc_map=False):
        print("🔍 Loading vectorstores...")

        question_type = self.detect_question_type(question)

        base_folder = os.path.join(self.vector_store_path, chat_id)
        if not os.path.exists(base_folder):
            print(f"❌ Chat folder not found: {base_folder}")
            return ("", {}, question_type) if return_doc_map else ("", question_type)

        expander = SynonymExpander()
        expanded_query = expander.find_similar_words(question)

        contexts = []
        doc_map = {}

        for folder_name in os.listdir(base_folder):
            if document_names and folder_name not in [os.path.splitext(name)[0] for name in document_names]:
                continue  # ⛔ Skip docs not selected

            folder_path = os.path.join(base_folder, folder_name)
            index_file = os.path.join(folder_path, "index.faiss")

            if not os.path.exists(index_file):
                print(f"⚠️ Missing vectorstore for {folder_name}. Skipping.")
                continue

            try:
                vs = FAISS.load_local(
                    folder_path,
                    self.embedding_model,
                    allow_dangerous_deserialization=True
                )

                docs_with_scores = vs.similarity_search_with_score(expanded_query, k=top_k)
                top_docs = [doc for doc, score in docs_with_scores if score < 1.0]

                if not top_docs and docs_with_scores:
                    print("⚠️ Weak relevance detected. Using top-k fallback.")
                    top_docs = [doc for doc, score in docs_with_scores]

                if top_docs:
                    numbered_section = []
                    for idx, doc in enumerate(top_docs, start=1):
                        source = doc.metadata.get("source", folder_name)
                        doc_text = self.sanitize_text(doc.page_content.strip())
                        numbered = f"{idx}. {doc_text}"
                        numbered_section.append(numbered)
                        doc_map.setdefault(source, []).append(numbered)
                    contexts.append("\n".join(numbered_section))

            except Exception as e:
                print(f"❌ Failed loading {folder_path}: {e}")

        merged_context = "\n\n".join(contexts)

        if return_doc_map:
            return merged_context, doc_map, question_type
        return merged_context, question_type
