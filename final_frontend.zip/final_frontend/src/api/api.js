import axios from "axios";

// ✅ Use backend IP without trailing slash
const BASE_URL = 'http://192.168.0.109:8000';

// ✅ Ask a question to a specific document
export const askQuestion = async (chatId, documentName, question) => {
  try {
    // 👇 Ensure the URL has NO trailing slash
    const url = `${BASE_URL}/api/ask`;

    console.log("✅ Sending POST to:", url); // Debug log

    const response = await axios.post(
      url,
      {
        chat_id: chatId,
        document_id: documentName,
        question: question,
      },
      {
        headers: {
          'Content-Type': 'application/json',
        },
        timeout: 15000,
      }
    );

    return response.data;
  } catch (error) {
    console.error('❌ askQuestion API Error:', error);

    throw error.response?.data || {
      error: 'Failed to get response from backend. Please check backend logs.',
    };
  }
};

// ✅ List all uploaded documents
export const listDocuments = async () => {
  try {
    const url = `${BASE_URL}/list_documents`;
    const res = await axios.get(url);
    return res.data;
  } catch (error) {
    console.error('❌ Error in listDocuments:', error);
    throw new Error('Failed to fetch document list.');
  }
};
